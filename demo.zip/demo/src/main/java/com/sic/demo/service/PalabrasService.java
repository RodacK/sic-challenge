package com.sic.demo.service;

import org.springframework.stereotype.Service;

@Service
public class PalabrasService {
    
    public String invertir(String palabra) {
        StringBuilder stringBuilder = new StringBuilder(palabra);
        return stringBuilder.reverse().toString();
    }
}
