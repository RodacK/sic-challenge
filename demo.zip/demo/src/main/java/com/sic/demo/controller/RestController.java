package com.sic.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;

import com.sic.demo.model.Empleado;
import com.sic.demo.model.Pedido;
import com.sic.demo.model.Producto;
import com.sic.demo.model.Suma;
import com.sic.demo.service.ClienteService;
import com.sic.demo.service.EmpleadoService;
import com.sic.demo.service.PalabrasService;
import com.sic.demo.service.ProductoService;
import com.sic.demo.service.UtilService;

@CrossOrigin("*")
@org.springframework.web.bind.annotation.RestController()
public class RestController {

    @Autowired
    private ProductoService service;

    @Autowired
    private PalabrasService palabrasService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private UtilService sumaService;

    @Autowired
    private EmpleadoService empleadoService;

    

    @GetMapping("/productos/{codigo}")
    public ResponseEntity<Producto> getProducto(@PathVariable String codigo) {
        try {
            return new ResponseEntity<Producto>(service.getProducto(codigo), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<Producto>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
    }

    @GetMapping("/invertir")
    public ResponseEntity<String> invertir(@RequestParam String palabra) {
        try {
            return new ResponseEntity<String>(palabrasService.invertir(palabra), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
    }


    @GetMapping("/pedidos")
    public ResponseEntity<List<Pedido>> getPedidos(@RequestParam String nombre) {
        try {
            return new ResponseEntity<List<Pedido>>(clienteService.obtenerProductos(nombre), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<List<Pedido>>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
    }

    @PostMapping("/sumar")
    public ResponseEntity<Integer> sumar(@RequestBody Suma data) {
        try {
            return new ResponseEntity<Integer>(sumaService.sumar(data), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<Integer>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
    }


    @GetMapping("/empleados")
    public ResponseEntity<Empleado> getEmpleado(@RequestParam String nombre) {
        try {
            return new ResponseEntity<Empleado>(empleadoService.getEmpleado(nombre), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<Empleado>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
    }


    @PostMapping("/sumarlista")
    public ResponseEntity<Integer> sumar(@RequestBody List<Integer> data) {
        try {
            return new ResponseEntity<Integer>(sumaService.sumar(data), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<Integer>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
    }


    @GetMapping("/ispar")
    public ResponseEntity<Boolean> getEmpleado(@RequestParam Integer num) {
        try {
            return new ResponseEntity<Boolean>(sumaService.isPar(num), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<Boolean>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
    }

    @PostMapping("/ordenar")
    public ResponseEntity<List<String>> ordenar(@RequestBody List<String> data) {
        try {
            return new ResponseEntity<List<String>>(sumaService.ordenar(data), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<List<String>>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
    }
}
