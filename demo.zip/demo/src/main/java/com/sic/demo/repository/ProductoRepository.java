package com.sic.demo.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.spi.LoggerContextFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.sic.demo.model.Producto;

import jakarta.inject.Singleton;

@Singleton
@Repository
public class ProductoRepository {

    Logger logger = LoggerFactory.getLogger(ProductoRepository.class);
    
    private List<Producto> productos = new ArrayList<Producto>();

    public ProductoRepository(){
        productos.add(Producto.builder().codigo("1").descripcion("lol").nombre("lol").precio(Float.valueOf("323.2")).build());
    }


    public Optional<Producto> getProducto(String codigo) {
        logger.info(codigo);
        //return Optional.of(productos.get(0));
        return productos.stream().filter(a -> a.getCodigo().equals(codigo)).findFirst();
    }
}
