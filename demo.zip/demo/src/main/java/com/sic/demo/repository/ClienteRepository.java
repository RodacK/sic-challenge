package com.sic.demo.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.sic.demo.model.Cliente;
import com.sic.demo.model.Pedido;

@Repository
public class ClienteRepository {
    private List<Cliente> clientes = new ArrayList<Cliente>();

    public ClienteRepository(){
        clientes.add(Cliente.builder().nombre("rob").direccion("sdsada").pedidos(new ArrayList<Pedido>()).build());
        agregarPedido("rob", Pedido.builder().fecha(new Date()).id(1).total(43.4).build());
    }

    public Cliente agregarPedido(String nombre, Pedido pedido){
        return clientes.stream().filter(a -> a.getNombre().equals(nombre)).findFirst().map(a -> {
            a.getPedidos().add(pedido);
            return a;
        }).get();
    }

    public List<Pedido> obtenerPedidos(String nombre){
        return clientes.stream().filter(a -> a.getNombre().equals(nombre)).findFirst().get().getPedidos();
    }

}
