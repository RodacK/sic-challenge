package com.sic.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sic.demo.model.Empleado;
import com.sic.demo.model.Producto;
import com.sic.demo.repository.EmpleadoRepository;
import com.sic.demo.repository.ProductoRepository;

@Service
public class EmpleadoService {
    
    @Autowired
    private EmpleadoRepository repository;


    public Empleado getEmpleado(String name) throws Exception {
        Optional<Empleado> result = repository.getEmpleado(name);
        if(result.isPresent()) {
            return result.get();
        } else {
            throw new Exception("no encontrado");
        }
    }


}
