package com.sic.demo.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.spi.LoggerContextFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.sic.demo.model.Empleado;
import com.sic.demo.model.Producto;

import jakarta.inject.Singleton;

@Singleton
@Repository
public class EmpleadoRepository {

    Logger logger = LoggerFactory.getLogger(EmpleadoRepository.class);
    
    private List<Empleado> empleados = new ArrayList<Empleado>();

    public EmpleadoRepository(){
        empleados.add(Empleado.builder().contratacion(new Date()).nombre("rob").salario(3213.2).build());
    }


    public Optional<Empleado> getEmpleado(String name) {
        logger.info(name);
        //return Optional.of(productos.get(0));
        return empleados.stream().filter(a -> a.getNombre().equals(name)).findFirst();
    }
}
