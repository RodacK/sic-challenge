package com.sic.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sic.demo.model.Suma;

@Service
public class UtilService {
    
    public Integer sumar(Suma data) {
        return data.getA() + data.getB();
    }

    public Integer sumar(List<Integer> data) {
        return data.stream().reduce((a, b) -> {return a+b;}).get();
    }

    public Boolean isPar(Integer num) {
        return num % 2 == 0 ? true : false;
    }


    public List<String> ordenar (List<String> palabras) {
        return palabras.stream().sorted().toList();
    }
}
