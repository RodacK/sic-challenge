se adjunta el postman collection
las querys sql estan en resources/templates/env.sql
tambien se respondieron preguntas en el doc